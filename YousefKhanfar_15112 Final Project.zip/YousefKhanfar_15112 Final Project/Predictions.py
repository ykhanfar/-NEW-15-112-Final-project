
from keras.models import Sequential,load_model
from keras.layers import Dense, Conv2D, MaxPooling2D, Dropout, Flatten
from PIL import Image
import cv2
import os
import numpy as np
from random import shuffle
from random import randint
from tqdm import tqdm
import matplotlib.pyplot as plt
import Segmentor
def predict(data,m='MExpressionModelV3(H).hd5'):
    conversion = {'minus':'-','plus':'+','div':'/','times':'*'}
    labels = ['minus','plus','div','times','0','1','2','3','4','5','6','7','8','9']
    predictions = []
    model = load_model(m)
    for i in data:
        p = model.predict(i)
        label = labels[np.argmax(p)]
        if label in conversion:
            predictions.append(conversion[label])
        else:
            predictions.append(label)
    return predictions

