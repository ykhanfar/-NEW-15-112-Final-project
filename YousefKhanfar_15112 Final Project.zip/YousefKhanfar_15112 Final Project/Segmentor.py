import cv2
import matplotlib.pyplot as plt
import numpy as np
def getColor(img,axis='x',coord=0):
    height,width = img.shape
    colors = []
    if axis == 'x':
        for x in range(width):
            color = img.item(coord,x)
            colors.append(color)
    elif axis == 'y':
        for y in range(height):
            color = img.item(y,coord)
            colors.append(color)
    return colors
#horizontalSeg will constrict the image to only the full expression.
#It takes a binary image as input
def horizontalSeg(img):
    start = 0
    end = 0
    foundStart = False
    height,width = img.shape
    nextStart = False
    for y in range(height):
        rowColors = getColor(img,'x',y)
        if 0 in rowColors and foundStart == False:
            if nextStart == True:
                end = y
            else:
                start = y
                foundStart = True
        if 0 not in rowColors and foundStart == True:
            end = y
            foundStart = False
            nextStart = True
    return [start,end]
#verticalSeg uses horizontalSeg to obtain a list of 4-point lists.
#Each list within the list represents a bounding rectangle around one of the symbols
def verticalSeg(img):
    colStart,colEnd = 0,0
    foundStart = False
    height,width = img.shape
    symbols = []
    for x in range(width):
        colColors = getColor(img,'y',x)
        if 0 in colColors and foundStart == False:
            colStart = x
            foundStart = True
        if 0 not in colColors and foundStart == True:
            colEnd = x
            foundStart = False
            symbol = img[:,colStart:colEnd]
            rowStart,rowEnd = horizontalSeg(symbol)
            symbols.append([rowStart,rowEnd,colStart,colEnd])
    return symbols
#readSymbols takes the image of the full expression and returns a list of images for
#each digit.
def readSymbols(im,threshold=130):
    image = cv2.imread(im,cv2.IMREAD_GRAYSCALE)
    c,bIm = cv2.threshold(image,threshold,255,cv2.THRESH_BINARY)
    symbols = verticalSeg(bIm)
    imgData = []
    for i in symbols:
        section = bIm[i[0]:i[1]+1,i[2]:i[3]+1]
        dim = section.shape
        #Get the values necessary to make image 45x45
        vertical,horizontal = abs((45-dim[0])//2),abs((45-dim[1])//2)
        #Extend borders of image until it is 45x45
        newSection = cv2.copyMakeBorder(section,top=vertical,bottom=vertical,left=horizontal,right=horizontal,
                                        borderType=cv2.BORDER_CONSTANT,value=(255,255,255))
        c,final = cv2.threshold(cv2.resize(newSection,(45,45)),120,255,cv2.IMREAD_GRAYSCALE)
        imgData.append(np.array(final).reshape(1,45,45,1))
    return imgData
    
    


