#Name: Yousef Khanfar
#AndrewID: ykhanfar
import Segmentor as smt
import Predictions as prd
from tkinter import filedialog
import tkinter as tk
from PIL import ImageTk
from PIL import Image
import cv2
import os
#Please make sure that you have Segmentor.py and Predictions.py in the same folder as MEE.py
class infoMenu:
    def __init__(self):
        self.master = tk.Tk()
        self.master.geometry(('1000x700'))
        self.master.withdraw()
        self.frame = tk.Frame(self.master)
        self.mainText = tk.Text(self.frame,height=300,width=100,state='disabled',font=('Times New Roman',12))
        self.title = tk.Label(self.frame,text='Information and Instructions')
        text = 'Welcome to my Mathematical Expression Evaluator, or MEE for short. The features of my project may not seem too '\
        +'obvious at first glance, so this information menu is here to help you out.\n\n Instructions:\n\n-To choose a file, press the '\
        +'"Choose a file" button. Select a file in proper image format (jpeg, jpg, png, etc). The image will then be displayed.\n\n-The threshold '\
        +'determines the programs sensitivity to color intensity. The higher the threshold, the brighter a pixel needs to be to turn to white. Pixels '\
        +'which are not bright are converted to black.\n\n-If you check "Black and White", the image will be displayed as binary when you choose the file. '\
        +'If you check it after you picked the file, then you can use the threshold slider to tinker with the threshold. You can preview the image with the '\
        +'new threshold by pressing the "Preview" button.\n\n-Press the "Evaluate Expression" when you are happy with the image, and the program will attempt to '\
        +'read the expression and evaluate it. It will display the expression in text form as well as the result. You can tinker further to optimize this if it is not '\
        +'already optimal.'
        self.frame.pack()
        self.title.grid(row=0)
        self.mainText.grid(row=1)
        self.mainText.configure(state='normal')
        self.mainText.insert('end',text)
        self.mainText.configure(state='disabled')
        self.master.protocol('WM_DELETE_WINDOW',self.close)
    def open_(self):
        if self.close():
            self.master.deiconify()
    def close(self):
        self.master.withdraw()
        return True
class main:
    def __init__(self,master):
        root = master
        ## ============ Creating Widgets ============ ##
        self.frame = tk.Frame(root)
        self.title = tk.Label(self.frame,text='Mathematical Expression Evaluator')
        self.message= tk.Label(self.frame,text='')
        self.threshlabel = tk.Label(self.frame,text='Threshold:')
        self.threshold = tk.Entry(self.frame)
        self.upload = tk.Button(self.frame,text='Upload Picture')
        self.choose = tk.Button(self.frame,text='Choose a file',command=self.chooseFile)
        self.filename = tk.StringVar()
        self.chooselbl = tk.Label(self.frame,textvariable=self.filename)
        im = Image.open('initDisplay.jpg')
        im.thumbnail((400,300),Image.ANTIALIAS)
        self.image = ImageTk.PhotoImage(image=im,master=self.frame)
        self.path = ''
        self.display = tk.Canvas(self.frame,width=400,height=300)
        self.display.configure(bg='white')
        self.evaluate = tk.Button(self.frame,text='Evaluate Expression',command=self.evaluate)
        self.expression = tk.Text(self.frame,height=2,width=20,state='disabled',
                                  font = ('Times New Roman',16))
        self.blackwhite = tk.Checkbutton(self.frame,text='Black and White',command=self.blackAndWhite)
        self.slider = tk.Scale(self.frame,from_=0,to=255,orient='horizontal',length=255)
        self.slider.set(130)
        self.pvw = tk.Button(self.frame,text='Preview',command=self.preview)
        self.info = tk.Button(self.frame,text='[i]',command=self.disInfo)
        ## ============ Miscellaneous Utilities ========== ##
        self.infoMenu = infoMenu()
        #self.binary determines whether or not image is displayed as black and white
        self.binary = False
        #self.uploaded is only False when nothing has been uploaded yet
        self.uploaded = False
        ## ============ Initializing the Structure of the Window ========== ##
        self.frame.pack()
        self.title.grid(row=0,columnspan=4)
        self.info.grid(row=0,column=0)
        self.message.grid(row=7,columnspan=4)
        self.threshlabel.grid(row=3,column=0)
        self.blackwhite.grid(row=2,column=0)
        self.slider.grid(row=4,column=0,columnspan=2)
        self.pvw.grid(row=5,column=0,columnspan=2)
        self.display.grid(row=1,column=2,columnspan=2,rowspan=5)
        self.choose.grid(row=1,column=0)
        self.chooselbl.grid(row=1,column=1)
        self.display.create_image((50,50),image=self.image,anchor='nw')
        self.evaluate.grid(row=6,column=2)
        self.expression.grid(row=6,column=3)
    def chooseFile(self):
        #Get an image file
        cfile = filedialog.askopenfilename(initialdir = ".",title = "Choose a file",filetypes = (("jpeg files","*.jpg"),("all files","*.*"))).split('/')[-1]
        if cfile:
            #Get absolute path of the image file
            self.path = os.path.abspath(cfile)
            if len(cfile)>=10:
               cfile = cfile[:11]+'...'
            self.filename.set(cfile)
            #Read image based on checkbox
            if self.binary:
                im = cv2.imread(self.path,cv2.IMREAD_GRAYSCALE)
                thresh = self.slider.get()
                c,bIm = cv2.threshold(im,thresh,255,cv2.THRESH_BINARY)
                im = Image.fromarray(bIm)
            else:
                im = Image.open(self.path)
            #Display image
            im.thumbnail((400,300),Image.ANTIALIAS)
            self.image = ImageTk.PhotoImage(im,master=self.frame)
            self.display.create_image((10,10),image=self.image,anchor='nw')
            self.uploaded=True
            #Clear text box
            self.expression.configure(state='normal')
            self.expression.delete(1.0,'end')
            self.expression.configure(state='disabled')
        else:
            self.filename.set('No file chosen')
    def evaluate(self):
        if self.uploaded:
            #Run image through model
            thresh = self.slider.get()
            data = smt.readSymbols(self.path,threshold=thresh)
            predictions = prd.predict(data)
            expression = ''.join(predictions)
            try:
                #Attempt to evaluate expression
                answer = str(eval(expression))
                self.message.configure(text='Successful Evaluation')
                self.expression.configure(state='normal')
                self.expression.delete(1.0,'end')
                self.expression.insert('end',expression+' =\n'+answer)
                self.expression.configure(state='disabled')
            except:
                #Error message if expression cannot be evaluated
                self.message.configure(text='Could not evaluate. Try changing the threshold')
        else:
            self.message.configure(text='Please upload an expression')
    def blackAndWhite(self):
        self.binary = not self.binary
    def preview(self):
        if self.binary:
            #Read Image as grayscale, then convert to binary (black and white)
            im = cv2.imread(self.path,cv2.IMREAD_GRAYSCALE)
            thresh = self.slider.get()
            c,bIm = cv2.threshold(im,thresh,255,cv2.THRESH_BINARY)
            im = Image.fromarray(bIm)
            im.thumbnail((400,300),Image.ANTIALIAS)
            self.image = ImageTk.PhotoImage(im,master=self.frame)
            #Display binary image
            self.display.create_image((10,10),image=self.image,anchor='nw')
        else:
            im = Image.open(self.path)
            im.thumbnail((400,300))
            self.image = ImageTk.PhotoImage(im,master=self.frame)
            self.display.create_image((10,10),image=self.image,anchor='nw')
    def disInfo(self):
        self.infoMenu.open_()
    def close(self):
        self.infoMenu.master.destroy()
        root.destroy()
#Initialize main window with proper dimensions
root = tk.Tk()
root.geometry('700x450')
app = main(root)
root.protocol('WM_DELETE_WINDOW',app.close)
app.frame.mainloop()


